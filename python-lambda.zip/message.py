def handler(event, context):
    print("SQS START: --------------")
    print(event)
    print("SQS END: --------------")
